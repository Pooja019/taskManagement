import axios from "axios";

// ✅ POST: Login user
export const loginUser = (data) => {
  return axios.post("http://localhost:8080/auth/login", data);
};


export const fetchTasks = async () => {
  try {
    const token = sessionStorage.getItem("token");
    const user = JSON.parse(sessionStorage.getItem("user")); // get the user object
    const email = user?.email;

    const response = await axios.get(
      `http://localhost:8080/task/tasks/member/email/${email}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    return response.data;
  } catch (error) {
    console.error("Error fetching tasks:", error);
    throw error;
  }
};

